"""Accept raw legacy outputs before interleaving unchanged producer processes."""
import ast,hashlib,json,math,os,pathlib,platform,re,statistics,struct,subprocess,time,resource,datetime
root=pathlib.Path(__file__).resolve().parent
target=pathlib.Path('/tmp/martensite-040-surface-benchmark-target')
def bits(value): return struct.unpack('d',struct.pack('Q',value))[0]
def check(payload):
    rows={}
    for line in payload.decode().splitlines():
        match=re.fullmatch(r'(\S+) (eps=\d+|default mesh=(?:false|true)) properties=(\[.*\])(?: error=(\d+))?',line)
        assert match,line
        shape,mode,raw,error=match.groups();fields=ast.literal_eval(raw)
        assert len(fields)==16 and all(math.isfinite(bits(x)) for x in fields)
        if error is not None:assert math.isfinite(bits(int(error))) and bits(int(error))>=0
        assert (shape,mode) not in rows;rows[shape,mode]=bits(fields[0])
    assert len(rows)==30
    modes=['eps='+str(struct.unpack('Q',struct.pack('d',eps))[0]) for eps in [1.,1e-5,1e-9]]+['default mesh=false','default mesh=true']
    for mode in modes:
        assert abs(rows['cylinder',mode]-math.pi)<1e-12
        expected=2*math.sqrt(2) if mode=='default mesh=true' else math.pi
        assert abs(rows['meshed-cylinder',mode]-expected)<1e-12
        assert abs(rows['mesh-only',mode]-1)<1e-12
        assert abs(rows['mixed',mode]-(rows['ellipse',mode]+expected+1))<1e-12
    assert abs(rows['ellipse',modes[0]]-41.6317152760022)<0.002
    assert abs(rows['narrow',modes[0]]-1)<1e-12
    assert rows['narrow',modes[1]]==0
    return rows
binaries={label:target/label/'release/legacy-replay' for label in ['published','candidate']}
accepted={}
for label,binary in binaries.items():
    run=subprocess.run([str(binary)],capture_output=True,check=True)
    (root/(label+'-acceptance.stdout')).write_bytes(run.stdout)
    (root/(label+'-acceptance.stderr')).write_bytes(run.stderr)
    check(run.stdout);accepted[label]=run.stdout
assert accepted['published']==accepted['candidate']
expected=(root/'expected-properties.txt').read_bytes()
assert accepted['published']==expected
records=[]
(root/'samples.jsonl').write_text('')
for index,label in enumerate(['published','candidate','candidate','published','published','candidate']):
    name=f'sample-{index+1}-{label}';timing=root/(name+'.time.json')
    command=['/usr/bin/time','-f','{"wall_seconds":%e,"user_seconds":%U,"system_seconds":%S,"peak_rss_kib":%M,"exit_status":%x}', '-o',str(timing),str(binaries[label])]
    load_before=os.getloadavg();cpu_before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.perf_counter_ns()
    result=subprocess.run(command,capture_output=True,check=True)
    elapsed=time.perf_counter_ns()-start
    cpu_after=resource.getrusage(resource.RUSAGE_CHILDREN)
    (root/(name+'.stdout')).write_bytes(result.stdout);(root/(name+'.stderr')).write_bytes(result.stderr)
    assert result.stdout==accepted[label];check(result.stdout)
    record={'index':index+1,'revision':label,'command':command,'load_before':load_before,'parent_elapsed_ns':elapsed,'child_user_seconds':cpu_after.ru_utime-cpu_before.ru_utime,'child_system_seconds':cpu_after.ru_stime-cpu_before.ru_stime,**json.loads(timing.read_text())}
    records.append(record)
    with (root/'samples.jsonl').open('a') as stream:stream.write(json.dumps(record)+'\n')
summary={}
for label in binaries:
    samples=[r for r in records if r['revision']==label]
    summary[label]={key:{'median':statistics.median(r[key] for r in samples),'min':min(r[key] for r in samples),'max':max(r[key] for r in samples)} for key in ['wall_seconds','user_seconds','system_seconds','peak_rss_kib','parent_elapsed_ns','child_user_seconds','child_system_seconds']}
receipt={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'instrumentation':'Second bounded pass adds high-resolution RUSAGE_CHILDREN CPU windows for GNU time plus producer. Initial coarse pass is retained unchanged in coarse-pilot/.','scope':'Six owned shapes times five legacy modes;30rows/process;3 measured processes/revision after one acceptance/warmup process each. Not full corpus or accuracy closure.',
 'preparation':json.loads((root/'preparation.json').read_text()),'acceptance':{'rows':30,'property_fields_per_row':16,'all_modes_byte_equal':True,'published_equals_recorded_owned_payload':True,'payload_sha256':hashlib.sha256(expected).hexdigest(),'closed_form_controls':'cylinder PI, mesh2sqrt2, triangle1, mixed area additivity, fixed narrow1; fixed ellipse enclosure tolerance0.002. Adaptive narrow zero retained as legacy behavior, not certified accuracy.'},
 'settings':{'toolchain':'rustc1.99.0 b940084d7','profile':'release','features':'identical defaults;see resolved-features.json','build_jobs':2,'incremental':False,'external_dependencies':24,'build_commands':'cargo +1.99.0 build --offline --locked --release --manifest-path <consumer>/Cargo.toml','profile_overrides':None,'rustflags':None,'rustc_wrappers':None},
 'platform':platform.platform(),'logical_cpus':os.cpu_count(),'samples':records,'summary':summary,
 'limitations':['Shared host running other gates; no isolated CPU/core/frequency controls.','One30row producer/process; startup and fixture construction are included.','GNU time CPU/wall resolution is0.01seconds; parent_elapsed_ns adds independent wall detail including time-wrapper overhead.','Supplemental child CPU includes GNU time wrapper and producer; it is not integration-only CPU.','RSS is per-process high-water memory, not allocation/copy/lock accounting.','Three samples/revision establish bounded observation only; no controlled speedup claim.'],
 'input_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'producer.rs',root/'fixtures.rs',root/'support.rs',root/'resolved-external-dependencies.json',root/'resolved-features.json']},'binary_hashes':{label:hashlib.sha256(binary.read_bytes()).hexdigest() for label,binary in binaries.items()}}
(root/'report.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'acceptance':receipt['acceptance'],'summary':summary},indent=2))
