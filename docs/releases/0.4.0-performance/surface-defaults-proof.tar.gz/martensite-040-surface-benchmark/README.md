# Bounded release surface-property measurement

This compares the actual published v0.3.6 commit
`98d408444db53e6f4410adf578590e53d9062aff` with candidate
`8190ae446554eb9007d15eae98982b2369558f37` using only the established APIs.
No product source, CLI, package version, test budget or baseline was changed.

The exact retained producer, fixture module and serialization module are copied
unchanged for both revisions. Their hashes are in preparation.json. Both release
builds use rustc 1.99.0, the same default features and the same 24 external package
records. The external consumer manifests differ only in dependency paths. Existing Cargo fingerprints record matching compiler, profile and configuration
fields and empty Rust flags for corresponding library/binary compilations.
The full build launcher argv and environment were not independently retained;
wrapper absence and the absence of environment or profile overrides are not
proven by this archive. The build command template and jobs/incremental settings
in the report are operator records.

Before timing, each executable passed all 30 rows (six shapes, five modes), with
all 16 raw property fields and the explicit error bits identical to each other
and to the retained owned payload. Its SHA256 is
`fba1b5dacb96c46739f344b2a9157ec9a47f4dbc956f0c15be6056b39da61edc`.
Cylinder, existing mesh and triangle areas, fixed narrow-square area, a fixed
ellipse enclosure and mixed-shape additivity also pass. The adaptive narrow
square's existing zero is replayed as legacy behavior; this is not an accuracy
or full-corpus acceptance claim.

Three processes per revision were measured in interleaved order
published/candidate/candidate/published/published/candidate, after acceptance
runs. Each process runs the unchanged 30-row producer once. GNU time records
wall, user CPU, system CPU and peak RSS. Its 0.01-second resolution rounds most
CPU observations to zero. The second bounded pass also records high-resolution
RUSAGE_CHILDREN CPU windows and a monotonic parent wall window. These include
the time wrapper and producer startup, fixture construction and output. The
first pass remains unchanged in coarse-pilot/; it was not discarded to choose
favorable observations.

| Median, supplemental pass | Published v0.3.6 | Candidate |
| --- | ---: | ---: |
| Parent wall, milliseconds | 11.193 | 8.463 |
| Child CPU, milliseconds | 10.994 | 8.377 |
| Peak RSS, KiB | 12,224 | 12,588 |

Wall ranges were 10.958–12.378 ms and 8.374–9.688 ms. RSS ranges were
12,084–12,296 KiB and 12,324–12,776 KiB. Full GNU time records, high-resolution
windows, process order and host load are in samples.jsonl and report.json.

These are short samples on a shared host running other gates, without CPU
pinning, frequency controls or load isolation. They describe the observed
workload and do not establish a controlled speedup or a general performance
change. RSS measures process high-water memory, not allocations or lock costs.

Build logs, manifests, locks, resolved features, compiler identity, producer and
raw outputs are retained here. Source exports and executables remain in the
external scratch/cache paths recorded by the preparation and measurement
scripts. The compact proof archive omits those exports and binaries, whose
hashes are recorded. Run verify.py to check retained outputs and sample hashes;
rerunning measure.py requires the retained binaries and overwrites the current observation,
so preserve the supplied records first.
