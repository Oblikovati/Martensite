import pathlib,subprocess,shutil,json,hashlib,os
repo=pathlib.Path('/home/vmiguel/git/oblikovati-workspace/Martensite/.slim/worktrees/source-sdk-publication-plan')
root=pathlib.Path('/tmp/martensite-040-surface-benchmark');root.mkdir(exist_ok=True)
revisions={'published':'98d408444db53e6f4410adf578590e53d9062aff','candidate':'8190ae446554eb9007d15eae98982b2369558f37'}
source=repo/'docs/features/surface-property-policy/legacy-replay/producer.rs.txt'
(root/'producer.rs').write_bytes(source.read_bytes())
for name in ['fixtures.rs','support.rs']:
 (root/name).write_bytes((repo/'crates/martensite-tktopalgo/tests/surface_property_policy'/name).read_bytes())
for label,revision in revisions.items():
 tree=root/(label+'-source');tree.mkdir(exist_ok=True)
 archive=root/(label+'-source.tar')
 subprocess.run(['git','-C',str(repo),'archive','--format=tar','--output='+str(archive),revision],check=True)
 subprocess.run(['tar','-xf',str(archive),'-C',str(tree)],check=True)
 consumer=root/label;consumer.mkdir(exist_ok=True)
 (consumer/'main.rs').write_bytes(source.read_bytes())
 for name in ['fixtures.rs','support.rs']:(consumer/name).write_bytes((root/name).read_bytes())
 dependencies=['martensite-tktopalgo','martensite-tkbrep','martensite-tkernel','martensite-tkg3d','martensite-tkmath','martensite-tkgeombase']
 manifest='[package]\nname="legacy-surface-release-benchmark"\nversion="0.0.0"\nedition="2024"\n\n[[bin]]\nname="legacy-replay"\npath="main.rs"\n\n[dependencies]\n'
 manifest+=''.join(f'{name} = {{ path = "{tree}/crates/{name}" }}\n' for name in dependencies)
 (consumer/'Cargo.toml').write_text(manifest)
 shutil.copyfile(tree/'Cargo.lock',consumer/'Cargo.lock')
receipt={'revisions':revisions,'producer_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'fixture_hashes':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['fixtures.rs','support.rs']},'scope':'External scratch only; legacy API30 rows; no production source/manifest modifications.'}
(root/'preparation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(root)
