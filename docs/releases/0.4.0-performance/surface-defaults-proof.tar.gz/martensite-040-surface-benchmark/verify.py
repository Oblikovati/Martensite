"""Validate retained acceptance and sample evidence without running the kernel."""
import ast,hashlib,json,math,pathlib,re,struct,statistics
root=pathlib.Path(__file__).resolve().parent
report=json.loads((root/'report.json').read_text())
source=ast.parse((root/'measure.py').read_text())
functions=[node for node in source.body if isinstance(node,ast.FunctionDef) and node.name in ['bits','check']]
exec(compile(ast.Module(body=functions,type_ignores=[]),'retained-controls','exec'))
expected=(root/'expected-properties.txt').read_bytes()
assert hashlib.sha256(expected).hexdigest()==report['acceptance']['payload_sha256']
for folder in [root,root/'coarse-pilot']:
    for path in folder.glob('sample-*.stdout'):
        assert path.read_bytes()==expected
        assert len(check(path.read_bytes()))==30
for name,expected_hash in report['input_hashes'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected_hash
for label in ['published','candidate']:
    assert hashlib.sha256((root/label/'main.rs').read_bytes()).hexdigest()==report['preparation']['producer_sha256']
    for name,digest in report['preparation']['fixture_hashes'].items():
        assert hashlib.sha256((root/label/name).read_bytes()).hexdigest()==digest
    assert (root/(label+'-acceptance.stdout')).read_bytes()==expected
    samples=[sample for sample in report['samples'] if sample['revision']==label]
    assert len(samples)==3 and all(sample['exit_status']==0 for sample in samples)
    assert statistics.median(sample['peak_rss_kib'] for sample in samples)==report['summary'][label]['peak_rss_kib']['median']
print('PASS: exact producer hashes,30-row acceptance,12 timed output payloads,3 final samples per revision')
