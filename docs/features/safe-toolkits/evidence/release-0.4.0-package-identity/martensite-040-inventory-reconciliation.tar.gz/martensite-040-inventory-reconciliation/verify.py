"""Verify retained captures without Cargo, Git, network or original checkouts."""
import collections, gzip, hashlib, json, pathlib
root = pathlib.Path(__file__).resolve().parent
manifest = json.loads((root / 'inputs.json').read_text())
for name, expected in manifest.items():
    payload = (root / name).read_bytes()
    if name.endswith('.gz'):
        assert hashlib.sha256(payload).hexdigest() == expected['compressed_sha256']
        payload = gzip.decompress(payload)
        assert hashlib.sha256(payload).hexdigest() == expected['uncompressed_sha256']
    else:
        assert hashlib.sha256(payload).hexdigest() == expected['sha256']
def read(label, name):
    return gzip.decompress((root / label / (name + '.gz')).read_bytes())
def report(label):
    return json.loads(read(label, 'latest.json'))
def prefix(label):
    for line in read(label, 'compiler.stdout.jsonl').splitlines():
        event = json.loads(line)
        path = event.get('manifest_path', '')
        suffix = '/crates/martensite-tkernel/Cargo.toml'
        if path.endswith(suffix):
            return path[:-len(suffix)]
    raise AssertionError('missing TKERNEL diagnostic root')
def records(label):
    result = []
    workspace_prefix = prefix(label)
    for line in read(label, 'compiler.stdout.jsonl').splitlines():
        event = json.loads(line)
        if event.get('reason') != 'compiler-message': continue
        if (event['message'].get('code') or {}).get('code') != 'unsafe_code': continue
        result.append(json.dumps(event, sort_keys=True) .replace(workspace_prefix, '<workspace>')
          .replace('path+file://<workspace>/crates/martensite-tkernel#0.3.6', 'path+file://<workspace>/crates/martensite-tkernel#0.4.0'))
    return collections.Counter(result)
a, b = records('old'), records('candidate')
assert a == b and sum(a.values()) == 5155
old = report('old')['diagnostics']['workspace_summary']
new = report('candidate')['diagnostics']['workspace_summary']
for row in old:
    if row['location']['package'] == 'workspace:martensite-tkernel@0.3.6':
        row['location']['package'] = 'workspace:martensite-tkernel@0.4.0'
assert old == new and len(new) == 449
print('PASS: 5155 raw diagnostic events; 449 ordered summary groups; exact label-only delta')
