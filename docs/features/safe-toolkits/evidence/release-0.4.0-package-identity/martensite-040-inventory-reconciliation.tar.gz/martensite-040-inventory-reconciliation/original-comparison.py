import collections, hashlib, json, pathlib, subprocess, tomllib
workspace = pathlib.Path('/home/vmiguel/git/oblikovati-workspace/Martensite/.slim/worktrees')
old = workspace / 'package-publication-history'
new = workspace / 'source-sdk-publication-plan'
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def events(lane):
    path = lane / 'target/unsafe-inventory/compiler.stdout.jsonl'
    records = []
    for line in path.open():
        event = json.loads(line)
        if event.get('reason') != 'compiler-message': continue
        if (event['message'].get('code') or {}).get('code') != 'unsafe_code': continue
        encoded = json.dumps(event, sort_keys=True).replace(str(lane), '<workspace>')
        encoded = encoded.replace('path+file://<workspace>/crates/martensite-tkernel#0.3.6', 'path+file://<workspace>/crates/martensite-tkernel#0.4.0')
        records.append(encoded)
    return collections.Counter(records)
def git(*args): return subprocess.check_output(['git', '-C', str(new), *args], text=True).strip()
old_report = json.loads((old / 'target/unsafe-inventory/latest.json').read_text())
new_report = json.loads((new / 'target/unsafe-inventory/latest.json').read_text())
baseline_path = new / 'docs/features/safe-toolkits/compiler-baselines/x86_64-unknown-linux-gnu.json'
baseline = json.loads(baseline_path.read_text())
summary = json.loads(json.dumps(baseline['summary']).replace('workspace:martensite-tkernel@0.3.6','workspace:martensite-tkernel@0.4.0'))
a,b = events(old),events(new)
assert a == b, (sum((b-a).values()), sum((a-b).values()))
assert summary == new_report['diagnostics']['workspace_summary']
assert old_report['diagnostics']['workspace_summary'] == baseline['summary']
assert old_report['provenance']['compiler'] == new_report['provenance']['compiler']
def lock(revision): return tomllib.loads(git('show', revision + ':Cargo.lock'))['package']
old_external = [package for package in lock('991df6d7') if 'source' in package]
new_external = [package for package in lock('2abcde64') if 'source' in package]
assert old_external == new_external
source_trees = {name: {revision:git('rev-parse', revision + ':crates/' + name + '/src')
 for revision in ['659cc64a', '991df6d7', '2abcde64']}
 for name in ['martensite-cmath','martensite-tkernel','martensite-tkservice']}
assert all(len(set(revisions.values())) == 1 for revisions in source_trees.values())
proof = {
 'unsafe_emitting_source_trees':source_trees,
 'external_lock_entries_identical':old_external == new_external,
 'external_lock_entries_each':len(old_external),
 'old_revision':old_report['provenance']['revision'], 'candidate_revision':new_report['provenance']['revision'],
 'normalization':['absolute old/candidate workspace prefix to <workspace>', 'exact TKERNEL package_id version0.3.6 to0.4.0'],
 'unsafe_raw_events_each':sum(a.values()),'raw_events_added':sum((b-a).values()),'raw_events_removed':sum((a-b).values()),
 'ordered_summary_equal_after_single_package_label':summary == new_report['diagnostics']['workspace_summary'],
 'groups_each':len(summary),'workspace_primary_spans_each':sum(row['emitted_primary_spans'] for row in summary),
 'changed_summary_labels':{'workspace:martensite-tkernel@0.3.6':'workspace:martensite-tkernel@0.4.0'},
 'changed_groups':sum(row['location']['package']=='workspace:martensite-tkernel@0.3.6' for row in baseline['summary']),
 'compiler':baseline['compiler'],'old_clean':old_report['provenance']['working_tree_status']=='','candidate_clean':new_report['provenance']['working_tree_status']=='',
 'tkernel_source_tree_main991':git('rev-parse','991df6d7:crates/martensite-tkernel/src'),
 'tkernel_source_tree_candidate':git('rev-parse','2abcde64:crates/martensite-tkernel/src'),
 'toolchain_config_diff_main991_candidate':git('diff','991df6d7','2abcde64','--','rust-toolchain.toml','.cargo/config.toml','Cargo.toml'),
 'inputs':{str(path):digest(path) for lane in [old,new] for path in [lane/'target/unsafe-inventory/latest.json',lane/'target/unsafe-inventory/compiler.stdout.jsonl',lane/'target/unsafe-inventory/compiler.stderr.txt']},
 'baseline_sha256':digest(baseline_path),
 'scope':'Read-only comparison of retained actual native Linux captures. Other targets require exact native release-matrix validation; no baseline or source changes performed.'}
pathlib.Path('/tmp/martensite-040-inventory-comparison.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({k:v for k,v in proof.items() if k!='inputs'},indent=2))
