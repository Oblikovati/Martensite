fn main() {
    eprintln!("TSAN_SMOKE_MAIN_ENTERED");
    let worker = std::thread::spawn(|| 42u32);
    assert_eq!(worker.join().unwrap(), 42);
}
