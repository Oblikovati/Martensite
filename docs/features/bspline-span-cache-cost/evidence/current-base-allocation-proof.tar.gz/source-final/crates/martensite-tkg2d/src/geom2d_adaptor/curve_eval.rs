//! Evaluation of `Geom2dAdaptorCurve`.
//!
//! Elementary curves go through ElCLib on the recorded gp geometry. Bezier and
//! B-spline curves go through the span cache, except at the adaptor bounds of a
//! B-spline, which use the local evaluators on the boundary span, and except when
//! the curve had an evaluation representation at load time, which the curve then
//! evaluates itself. Offset curves combine the nested basis adaptor with
//! Geom2dOffsetCurveUtils.
use super::curve::Geom2dAdaptorCurve;
use super::curve_eval_order::{EvalD0, EvalD1, EvalD2, EvalD3, EvalOrder};
use super::curve_state::{AdaptorState, BSplineData, BezierData, CurveData};
use crate::geom2d::errors::undefined_derivative;
use crate::geom2d::offset_curve_utils::evaluate_dn;
use crate::geom2d::{Geom2dBSplineCurve, Geom2dCurve, Geom2dCurveD1, Geom2dCurveD2, Geom2dCurveD3};
use crate::geom2d_adaptor::span_cache::{self, BOUNDARY_LOCATE_TOLERANCE, CacheSource};
use martensite_tkernel::standard::Failure;
use martensite_tkmath::bsplclib::Cache;
use martensite_tkmath::elclib;
use martensite_tkmath::gp::{Point2, Vector2};

/// `EvalD0`; `d0(&mut state, 0.5)?`.
pub(super) fn d0(state: &mut AdaptorState, u: f64) -> Result<Point2, Failure> {
    evaluate::<EvalD0>(state, u)
}
/// `EvalD1`; `d1(&mut state, 0.5)?`.
pub(super) fn d1(state: &mut AdaptorState, u: f64) -> Result<Geom2dCurveD1, Failure> {
    evaluate::<EvalD1>(state, u)
}
/// `EvalD2`; `d2(&mut state, 0.5)?`.
pub(super) fn d2(state: &mut AdaptorState, u: f64) -> Result<Geom2dCurveD2, Failure> {
    evaluate::<EvalD2>(state, u)
}
/// `EvalD3`; `d3(&mut state, 0.5)?`.
pub(super) fn d3(state: &mut AdaptorState, u: f64) -> Result<Geom2dCurveD3, Failure> {
    evaluate::<EvalD3>(state, u)
}

// The shared switch of EvalD0..EvalD3 on the curve kind.
fn evaluate<O: EvalOrder>(state: &mut AdaptorState, u: f64) -> Result<O::Output, Failure> {
    if let Some(result) = O::elementary(&state.data, u) {
        return Ok(result);
    }
    if state.data.has_eval_rep() {
        return O::curve(state.curve()?, u);
    }
    let (first, last) = (state.first, state.last);
    match &mut state.data {
        CurveData::Bezier(bezier) => O::cached(bezier_cache(bezier, u)?, u),
        CurveData::BSpline(bspline) => bspline_eval::<O>(bspline, u, first, last),
        CurveData::Offset(offset) => {
            O::offset(u, &offset.basis_adaptor, offset.offset)?.ok_or_else(|| O::failure())
        }
        _ => O::curve(state.curve()?, u),
    }
}

fn bspline_eval<O: EvalOrder>(
    data: &mut BSplineData,
    u: f64,
    first: f64,
    last: f64,
) -> Result<O::Output, Failure> {
    if let Some((start, finish)) = boundary_span(&data.curve, u, first, last)? {
        return O::local(&data.curve, u, start, finish);
    }
    let valid: bool = data
        .cache
        .as_ref()
        .is_some_and(|cache| cache.is_cache_valid(u));
    if !valid {
        rebuild_bspline_cache(data, u)?;
    }
    O::cached(data.cache.as_ref().expect("cache built above"), u)
}

/// `IsBoundary` on the knots of `curve`; `boundary_span(&c, 0.0, 0.0, 1.0)?`.
pub(super) fn boundary_span(
    curve: &Geom2dBSplineCurve,
    u: f64,
    first: f64,
    last: f64,
) -> Result<Option<(i32, i32)>, Failure> {
    let locate = |bound: f64| curve.locate_u(bound, BOUNDARY_LOCATE_TOLERANCE, false);
    span_cache::boundary_span(u, (first, last), || curve.nb_knots(), locate)
}

// RebuildCache for a B-spline: create the cache once, then fill it on the span of `u`.
fn rebuild_bspline_cache(data: &mut BSplineData, u: f64) -> Result<(), Failure> {
    let curve: &Geom2dBSplineCurve = &data.curve;
    curve.with_cache_build_inputs(|(degree, periodic), flat, poles, weights| {
        let source = CacheSource {
            flat,
            poles,
            weights,
        };
        span_cache::rebuild_cache(&mut data.cache, &source, || degree, || periodic, u)
    })
}

// RebuildCache for a Bezier curve, which runs only while no cache exists: its single
// span is valid for every parameter.
fn bezier_cache(data: &mut BezierData, u: f64) -> Result<&Cache, Failure> {
    if data.cache.is_none() {
        let degree: i32 = data.curve.degree();
        let (poles, weights) = (data.curve.poles(), data.curve.weights());
        let periodic: bool = data.curve.is_periodic();
        let cache = span_cache::bezier_span_cache(degree, periodic, &poles, weights.as_ref(), u)?;
        data.cache = Some(cache);
    }
    Ok(data.cache.as_ref().expect("cache built above"))
}

/// `EvalDN`: ElCLib for elementary curves, the curve itself for Bezier curves, the
/// boundary span or the curve for B-splines, Geom2dOffsetCurveUtils for offsets;
/// `dn(&state, 0.5, 2)?`.
pub(super) fn dn(state: &AdaptorState, u: f64, n: i32) -> Result<Vector2, Failure> {
    match &state.data {
        CurveData::Line(line) => Ok(elclib::dn(u, line, n)),
        CurveData::Circle(circle) => Ok(elclib::dn(u, circle, n)),
        CurveData::Ellipse(ellipse) => Ok(elclib::dn(u, ellipse, n)),
        CurveData::Hyperbola(hyperbola) => Ok(elclib::dn(u, hyperbola, n)),
        CurveData::Parabola(parabola) => Ok(elclib::dn(u, parabola, n)),
        CurveData::BSpline(bspline) if !bspline.eval_rep.is_some() => {
            match boundary_span(&bspline.curve, u, state.first, state.last)? {
                Some((start, finish)) => bspline.curve.local_dn(u, start, finish, n),
                None => state.curve()?.eval_dn(u, n),
            }
        }
        CurveData::Offset(offset) if !offset.eval_rep.is_some() => {
            offset_dn(&offset.basis_adaptor, offset.offset, u, n)
        }
        _ => state.curve()?.eval_dn(u, n),
    }
}

fn offset_dn(basis: &Geom2dAdaptorCurve, offset: f64, u: f64, n: i32) -> Result<Vector2, Failure> {
    evaluate_dn(u, basis, offset, n)?
        .ok_or_else(|| undefined_derivative("Geom2dAdaptor_Curve::EvalDN: evaluation failed"))
}
